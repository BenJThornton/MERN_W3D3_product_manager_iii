const Product = require("../models/Product.model");

module.exports = {
    //read
    findAll : (req, res)=> {
        Product.find()
        .then(allProducts => res.json(allProducts))
        .catch(err => res.json({error: err}))
    },
    findOne : (req, res) =>{
        Product.findById(req.params.id)
        .then(product => res.json(product))
        .catch(err => res.json({error: err}))
    },

    //create
    create : (req, res) =>{
        Product.create(req.body)
        .then(newProduct => res.json(newProduct))
        .catch(err => res.json({error: err}))
    },

    //update
    update : (req, res) =>{
        Product.findByIdAndUpdate(req.params.id, req.body, {
            new: true, runValidators: true})
        .then((updatedProduct) => {
            res.json(updatedProduct)
        })
        .catch(err => res.json({message: "Error res", error: err}))
    },

    //delete
    delete : (req, res) =>{
        Product.findByIdAndDelete(req.params.id)
        .then(result => res.json(result))
        .catch(err => res.json({message: "error res", error: err}))
    }
}