const express = require('express');
const cors = require('cors');
const app = express();
const PORT= 8000;
const DB = "products_db";

// middleware

app.use(cors(), express.json(), express.urlencoded({extended:true}));

//database connector
require("./config/mongoose.config")(DB)

//connect routes
require("./routes/product.routes")(app);

//end of server
app.listen(PORT, ()=>{
    console.log(`Server is up on port ${PORT}`)
})