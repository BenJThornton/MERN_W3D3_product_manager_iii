const mongoose = require('mongoose');

const ProductSchema = new mongoose.Schema({
    title: {
        type:String,
        required: [true, "{PATH} must be present"],
        minlength: [3, "{PATH} must be at least 3 chars long"]
    },
    price: {
        type:String,
        required: [true, "{PATH} must be present"],
        minlength: [4, "{PATH} must be at least 3 chars long"]
    },
    description: {
        type:String,
        required: [true, "{PATH} must be present"],
        minlength: [5, "{PATH} must be at least 3 chars long"]
    }  
}, {timestamps: true});

//make the product schema and export
const Product = mongoose.model("Product", ProductSchema);
module.exports = Product;