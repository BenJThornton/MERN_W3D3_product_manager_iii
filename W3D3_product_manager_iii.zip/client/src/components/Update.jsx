import React, { useState, useEffect } from 'react';
import { useHistory, useParams } from 'react-router-dom';
import axios from 'axios';


const Update = (props) => {

    let history = useHistory();

    const { id } = useParams();

    const [title, setTitle] = useState("");
    const [price, setPrice] = useState("");
    const [description, setDescription] = useState("");

    useEffect(() => {
        axios.get("http://localhost:8000/api/products/" + id)
            .then(res => {
                console.log(res.data);
                setTitle(res.data.title)
                setPrice(res.data.price)
                setDescription(res.data.description)
            })
            .catch(err => console.log(err))
    }, [])

    const onSubmitHandler = e => {
        e.preventDefault();
        const newProduct = {
            title: title,
            price: price,
            description: description
        }
        axios.put("http://localhost:8000/api/products/" + id, newProduct)
            .then(res => {
                console.log("Response: ", res);
                history.push('/')
            })
            .catch(err => console.log("Error: ", err))
    }
    return (
        <form onSubmit={onSubmitHandler}>
            <p>
                <label>Title</label>
                <input type="text" onChange={e => setTitle(e.target.value)} value={title} />
            </p>
            <p>
                <label>Price</label>
                <input type="text" onChange={e => setPrice(e.target.value)} value={price} />
            </p>
            <p>
                <label>Description</label>
                <input type="text" onChange={e => setDescription(e.target.value)} value={description} />
            </p>
            <input type="submit" />
        </form>
    )
}

export default Update;