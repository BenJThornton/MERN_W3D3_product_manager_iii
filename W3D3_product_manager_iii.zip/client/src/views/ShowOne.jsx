import React, {useState, useEffect} from 'react';
import {useParams, useHistory} from 'react-router-dom';
import axios from 'axios';


const ShowOne = (props) =>{

    const {id} = useParams();

    let history = useHistory();

    const [thisProduct, setThisProduct] = useState({});

    useEffect(()=>{
        axios.get(`http://localhost:8000/api/products/${id}`)
        .then(res =>{
            console.log(res.data);
            setThisProduct(res.data)
        })
        .catch(err => console.log(err))
    }, [])

    const deleteProduct = (deleteId) =>{
        axios.delete("http://localhost:8000/api/products/"+ deleteId)
        .then(res =>{
            console.log(res);
            console.log("Success!")
            history.push('/')

        })
        .catch(err => console.log(err))
    }

    return(
        <div>
            <h2>
                {thisProduct.title}
            </h2>
            <p>
                Price: {thisProduct.price}
            </p>
            <p>
                Description:  {thisProduct.description}
            </p>
            <p>
                Created: {Date(thisProduct.createdAt)}
            </p>
            <button onClick={()=>deleteProduct(thisProduct._id)}>Delete</button>
        </div>
    )
}

export default ShowOne;