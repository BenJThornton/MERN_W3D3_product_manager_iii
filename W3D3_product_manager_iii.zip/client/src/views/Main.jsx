import React, {useState, useEffect} from 'react';
import axios from 'axios';
import {Link} from 'react-router-dom';

const Main = (props) => {

    const [products, setProducts]= useState([]);

    useEffect(() => {
        getProductsFromDB()
    }, [])

    const getProductsFromDB = () =>{
        axios.get('http://localhost:8000/api/products')
            .then(res =>{
                console.log(res.data);
                setProducts(res.data);
            })
            .catch( err => console.log(err))
    }
    const deleteProduct = (deleteId) =>{
        axios.delete("http://localhost:8000/api/products/"+ deleteId)
        .then(res =>{
            console.log(res);
            console.log("Success!")
            
            //remove from DOM after success
            setProducts(products.filter((product) => product._id !== deleteId))

        })
        .catch(err => console.log(err))
    }

    return(
        <div>
            
            <div>
                <h3>All Products</h3>
                {
                    products.map((product, idx) =>{
                        return(
                            <div key={product._id}>
                                <h4>
                                    <Link to={'/products/'+product._id}>{product.title}</Link>
                                    <Link to={'/products/update/'+product._id}>Update</Link>
                                    <button onClick={()=>deleteProduct(product._id)}>Delete</button>
                                </h4>
                            </div>
                        )
                    })
                }
            </div>
        </div>
        
    )
}

export default Main;
